# PROJECT TOOLS JEFF

Android/Kotlin starter dashboard for an Android utility app.

## Dashboard update
- Animated Itachi Uchiha banner (9-frame GIF, cinematic red/black moon theme).
- The GIF loops in the dashboard header using a lightweight Android Movie view.
- Three-dot overflow menu with developer handle `@jeffsukamakan`.
- Developer menu includes a TikTok profile shortcut.

## Included starter modules
- Shizuku connection/permission status.
- Save current `wm size` as the normal resolution and restore it later.
- Basic UI animation-scale adjustment (not a guaranteed FPS boost).
- Optional non-interactive crosshair overlay.
- Installed-app/game launcher picker.

## Not included
- Game-process injection, automatic headshot/aim manipulation, memory editing, or anti-cheat bypass.
- Guaranteed FPS unlock/boost. Android apps cannot promise extra FPS beyond device, display, thermal, and game limits.
- Advanced V-GEN controls; current performance actions are basic system settings only.

## Build
1. Open this folder in Android Studio.
2. Use JDK 17 and Android Gradle Plugin 8.7.3.
3. Sync Gradle and build the debug APK.
4. Install Shizuku, start its service, then open this app and grant permission.

Designed as a starter for Android 6+; test on the target device. On ColorOS, Shizuku may need restarting after reboot. Verify resolution before restoring it.


## Animated banner
- GIF asset: `app/src/main/assets/itachi_banner.gif`
- Replace this file to change the animated header artwork. Keep the filename unchanged.
- The included 9-frame animation loops automatically in the Home dashboard.

## Build helper
This archive includes `gradlew` and `gradle-wrapper.properties`. The launcher bootstraps Gradle 8.9 if no Gradle installation is available; it requires Java 17, `curl`, `unzip`, and an installed Android SDK. It is a lightweight bootstrap script, not the official Gradle Wrapper JAR distribution.

### Build from a terminal
From this project directory, run:
```sh
chmod +x gradlew
./gradlew assembleDebug
```
The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

For Android IDE users, open the `PROJECT_TOOLS_JEFF` folder as an existing Gradle project and let the IDE configure its Android SDK and Gradle runtime.
