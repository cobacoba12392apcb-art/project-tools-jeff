package com.jeff.projecttools

import android.app.Service
import android.content.Intent
import android.graphics.*
import android.os.IBinder
import android.view.*

class CrosshairService : Service() {
    private var windowManager: WindowManager? = null
    private var view: View? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (view != null) return START_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        view = CrosshairView(this)
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        windowManager?.addView(view, params)
        return START_STICKY
    }
    override fun onDestroy() {
        if (view != null) windowManager?.removeView(view)
        view = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private class CrosshairView(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GREEN; strokeWidth = 3f; style = Paint.Style.STROKE
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            val r = 12f
            canvas.drawCircle(cx, cy, r, paint)
            canvas.drawLine(cx - 22, cy, cx - 7, cy, paint)
            canvas.drawLine(cx + 7, cy, cx + 22, cy, paint)
            canvas.drawLine(cx, cy - 22, cx, cy - 7, paint)
            canvas.drawLine(cx, cy + 7, cx, cy + 22, paint)
        }
    }
}
