package com.jeff.projecttools

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 13, 16)
    private val panel = Color.rgb(26, 27, 31)
    private val line = Color.rgb(53, 54, 60)
    private val accent = Color.rgb(235, 42, 75)
    private val muted = Color.rgb(151, 153, 161)
    private lateinit var root: LinearLayout
    private lateinit var shizukuStatus: TextView
    private val requestCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener { code, _ -> if (code == requestCode) refreshShizuku() }
        showHome()
    }

    private fun shape(color: Int, stroke: Int = line, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius * resources.displayMetrics.density; setStroke(dp(1), stroke) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }

    private fun label(value: String) = text(value, 17f, Color.WHITE, true).apply {
        setPadding(dp(2), dp(15), dp(2), dp(9))
    }

    private fun button(value: String, action: () -> Unit): TextView = text(value, 13f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(13), dp(10), dp(13), dp(10))
        background = shape(panel)
        setOnClickListener { action() }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = shape(panel)
    }

    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun gap(parent: LinearLayout, height: Int = 8) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun initRoot() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(16), dp(17), dp(8))
            setBackgroundColor(bg)
        }
    }

    private fun showHome() {
        initRoot()
        val top = row()
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("PROJECT TOOLS JEFF", 23f, Color.WHITE, true))
        brand.addView(text("Hi, OWNER", 12f, muted))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(button("⋮") { showDeveloperMenu() })
        root.addView(top)
        root.addView(label("Latest news"))

        val banner = FrameLayout(this).apply {
            background = shape(Color.rgb(18, 17, 21), accent, 16f)
            clipToOutline = true
        }
        banner.addView(ItachiGifView(this), FrameLayout.LayoutParams(-1, -1))
        val bannerShade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(225, 5, 5, 8)))
        }
        banner.addView(bannerShade, FrameLayout.LayoutParams(-1, -1))
        val news = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(14), dp(12), dp(14), dp(13))
        }
        news.addView(text("LATEST NEWS", 11f, Color.WHITE, true))
        news.addView(text("PROJECT TOOLS JEFF", 20f, Color.WHITE, true))
        news.addView(text("Optimize · Enhance · Play Better", 12f, Color.LTGRAY))
        banner.addView(news, FrameLayout.LayoutParams(-1, -1))
        root.addView(banner, LinearLayout.LayoutParams(-1, dp(178)))

        root.addView(label("Tools"))
        val tools = row()
        listOf("SMART RES", "AIMTRICK", "V-GEN", "FPS INFO").forEachIndexed { i, s ->
            val b = button(s) { when (i) { 0 -> showResolution(); 1 -> showAimtrick(); 2 -> showVgen(); else -> showMonitor() } }
            val lp = LinearLayout.LayoutParams(0, dp(42), 1f); lp.marginEnd = dp(5)
            tools.addView(b, lp)
        }
        root.addView(tools)

        root.addView(label("Games"))
        val games = row()
        val gameSpace = button("▦   Game Launcher\n      Open installed games") { launchGamePicker() }
        val dev = button("◉   Developer\n      @jeffsukamakan") { showDeveloperMenu() }
        games.addView(gameSpace, LinearLayout.LayoutParams(0, dp(66), 1f).apply { marginEnd = dp(7) })
        games.addView(dev, LinearLayout.LayoutParams(0, dp(66), 1f))
        root.addView(games)

        root.addView(label("Service Status"))
        val service = card()
        val sr = row()
        sr.addView(text("▣   Shizuku Service", 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        shizukuStatus = text("checking", 12f, Color.rgb(91, 190, 120))
        sr.addView(shizukuStatus)
        service.addView(sr)
        service.setOnClickListener { connectShizuku() }
        root.addView(service)

        root.addView(label("Phone info"))
        val info = card()
        info.addView(infoLine("Phone Name", android.os.Build.MODEL))
        info.addView(infoLine("Android Version", android.os.Build.VERSION.RELEASE))
        info.addView(infoLine("Build ID", android.os.Build.DISPLAY))
        info.addView(infoLine("SDK", android.os.Build.VERSION.SDK_INT.toString()))
        root.addView(info)

        root.addView(label("FPS info"))
        val fps = card()
        fps.addView(text("FPS monitoring depends on game and Android support.", 12f, muted))
        fps.addView(text("No simulated FPS values are displayed.", 11f, muted))
        root.addView(fps)

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        val nav = row().apply {
            background = shape(panel)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        listOf("⌂\nHome", "☰\nMenu", "⚙\nSettings").forEachIndexed { i, s ->
            val v = text(s, 13f, if (i == 0) Color.WHITE else muted, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(5))
                setOnClickListener { when(i) { 0 -> showHome(); 1 -> showMenu(); 2 -> showSettings() } }
            }
            nav.addView(v, LinearLayout.LayoutParams(0, dp(50), 1f))
        }
        root.addView(nav)
        setContentView(root)
        refreshShizuku()
    }

    private fun infoLine(k: String, v: String): TextView =
        text("$k                         :  $v", 11f, muted).apply { setPadding(0, dp(4), 0, dp(4)) }

    private fun refreshShizuku() {
        if (!::shizukuStatus.isInitialized) return
        val connected = Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        shizukuStatus.text = if (connected) "running" else "not connected"
        shizukuStatus.setTextColor(if (connected) Color.rgb(91, 190, 120) else accent)
    }

    private fun connectShizuku() {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(this, "Start Shizuku service first.", Toast.LENGTH_LONG).show()
            return
        }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED)
            Shizuku.requestPermission(requestCode)
        else refreshShizuku()
    }

    private fun showDeveloperMenu() {
        AlertDialog.Builder(this).setTitle("Developer")
            .setMessage("PROJECT TOOLS JEFF\nDeveloper: @jeffsukamakan")
            .setPositiveButton("TikTok") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@jeffsukamakan")))
            }.setNegativeButton("Close", null).show()
    }

    private fun showResolution() {
        val options = arrayOf("Save current normal resolution", "Restore saved normal resolution")
        AlertDialog.Builder(this).setTitle("Smart Resolution").setItems(options) { _, which ->
            if (which == 0) saveNormalResolution() else restoreNormalResolution()
        }.show()
    }

    private fun showAimtrick() {
        AlertDialog.Builder(this).setTitle("Aimtrick")
            .setMessage("Crosshair overlay and visual alignment tools. This module does not alter game aim or generate automatic headshots.")
            .setPositiveButton("Enable crosshair") { _, _ ->
                if (!Settings.canDrawOverlays(this)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startService(Intent(this, CrosshairService::class.java))
            }.setNegativeButton("Turn off") { _, _ -> stopService(Intent(this, CrosshairService::class.java)) }
            .setNeutralButton("Close", null).show()
    }

    private fun showVgen() {
        AlertDialog.Builder(this).setTitle("V-GEN Performance")
            .setItems(arrayOf("Eco", "Balanced", "Performance")) { _, which ->
                when (which) {
                    0 -> applyAnimationScale("1")
                    1 -> applyAnimationScale("0.5")
                    2 -> applyAnimationScale("0")
                }
                Toast.makeText(this, "System animation preset applied.", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showMonitor() {
        AlertDialog.Builder(this).setTitle("FPS Monitor")
            .setMessage("Live FPS readings are not exposed consistently across Android games. This dashboard does not invent FPS values.")
            .setPositiveButton("OK", null).show()
    }

    private fun showMenu() {
        AlertDialog.Builder(this).setTitle("Menu").setItems(arrayOf("Smart Resolution", "Aimtrick", "V-GEN", "Game Launcher", "Developer")) { _, i ->
            when (i) { 0 -> showResolution(); 1 -> showAimtrick(); 2 -> showVgen(); 3 -> launchGamePicker(); 4 -> showDeveloperMenu() }
        }.show()
    }

    private fun showSettings() {
        AlertDialog.Builder(this).setTitle("Settings").setItems(arrayOf("Connect Shizuku", "Overlay permission", "Reset UI animation scale")) { _, i ->
            when (i) {
                0 -> connectShizuku()
                1 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                2 -> applyAnimationScale("1")
            }
        }.show()
    }

    private fun applyAnimationScale(value: String) {
        runShizuku("settings put global window_animation_scale $value; settings put global transition_animation_scale $value; settings put global animator_duration_scale $value")
    }

    private fun runShizuku(command: String): String? {
        return try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Connect Shizuku and grant permission first.", Toast.LENGTH_LONG).show()
                return null
            }
            val p = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            val code = p.waitFor()
            if (code == 0) out else throw RuntimeException(err.ifBlank { "Exit code $code" })
        } catch (e: Exception) {
            Toast.makeText(this, "Command failed: ${e.message}", Toast.LENGTH_LONG).show()
            null
        }
    }

    private fun saveNormalResolution() {
        val result = runShizuku("wm size")
        if (result != null) {
            getSharedPreferences("prefs", MODE_PRIVATE).edit().putString("normal_size", result.trim()).apply()
            Toast.makeText(this, "Normal resolution saved.", Toast.LENGTH_LONG).show()
        }
    }

    private fun restoreNormalResolution() {
        val saved = getSharedPreferences("prefs", MODE_PRIVATE).getString("normal_size", null)
        val match = saved?.let { Regex("(\\\\d{3,5}x\\\\d{3,5})").find(it) }
        if (match != null) runShizuku("wm size ${match.value}")
        else Toast.makeText(this, "Save normal resolution first.", Toast.LENGTH_LONG).show()
    }

    private fun launchGamePicker() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0).filter { it.activityInfo.packageName != packageName }
        val labels = apps.map { it.loadLabel(packageManager).toString() }
        if (apps.isEmpty()) {
            Toast.makeText(this, "No launchable apps found.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Choose game or app").setItems(labels.toTypedArray()) { _, which ->
            packageManager.getLaunchIntentForPackage(apps[which].activityInfo.packageName)?.let { startActivity(it) }
        }.show()
    }
}
