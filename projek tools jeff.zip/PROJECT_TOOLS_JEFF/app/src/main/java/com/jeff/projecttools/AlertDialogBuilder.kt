package com.jeff.projecttools
import android.content.Context
import android.app.AlertDialog
object AlertDialogBuilder {
    fun show(context: Context, labels: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(context).setTitle("Pilih game").setItems(labels.toTypedArray()) { _, which -> onPick(which) }.show()
    }
}
