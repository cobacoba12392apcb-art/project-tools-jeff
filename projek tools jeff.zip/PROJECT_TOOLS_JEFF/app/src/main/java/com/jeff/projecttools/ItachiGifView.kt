package com.jeff.projecttools

import android.content.Context
import android.graphics.Canvas
import android.graphics.Movie
import android.os.SystemClock
import android.view.View

/** Lightweight animated GIF banner, decoded from app assets. */
class ItachiGifView(context: Context) : View(context) {
    private val movie: Movie? = try {
        context.assets.open("itachi_banner.gif").use { Movie.decodeStream(it) }
    } catch (_: Exception) { null }
    private val startedAt = SystemClock.uptimeMillis()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val gif = movie ?: return
        val duration = gif.duration().takeIf { it > 0 } ?: 1000
        gif.setTime(((SystemClock.uptimeMillis() - startedAt) % duration).toInt())
        val sourceW = gif.width().toFloat().coerceAtLeast(1f)
        val sourceH = gif.height().toFloat().coerceAtLeast(1f)
        val scale = maxOf(width / sourceW, height / sourceH)
        val dx = (width - sourceW * scale) / 2f
        val dy = (height - sourceH * scale) / 2f
        val save = canvas.save()
        canvas.clipRect(0, 0, width, height)
        canvas.translate(dx, dy)
        canvas.scale(scale, scale)
        gif.draw(canvas, 0f, 0f)
        canvas.restoreToCount(save)
        postInvalidateDelayed(40)
    }
}
