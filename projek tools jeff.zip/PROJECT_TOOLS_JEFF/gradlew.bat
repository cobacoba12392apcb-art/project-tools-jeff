@echo off
setlocal
set ROOT=%~dp0
set VERSION=8.9
if not "%GRADLE_HOME%"=="" if exist "%GRADLE_HOME%\\bin\\gradle.bat" (
  call "%GRADLE_HOME%\\bin\\gradle.bat" -p "%ROOT%" %*
  exit /b %ERRORLEVEL%
)
echo Gradle 8.9 diperlukan. Gunakan Android Studio atau pasang Gradle 8.9, lalu jalankan: gradle -p . assembleDebug
exit /b 1
