# License Admin Portal — PROJECT TOOLS JEFF

Folder ini ditambahkan ke proyek Android asli. Kode Kotlin, banner Itachi GIF, dan modul dashboard yang sudah ada tidak diubah.

## Isi
- `index.html`: halaman admin statis untuk membuat, melihat, mencabut, dan reset ikatan perangkat lisensi.
- Halaman ini hanya frontend. Ia membutuhkan Cloudflare Worker API dan database D1.

## Hosting GitHub Pages
1. Upload folder `license-admin` ke repository GitHub.
2. Aktifkan **Settings → Pages** dan pilih branch/folder yang sesuai.
3. Buka `index.html`, ganti `API_BASE` dengan URL Worker Cloudflare milikmu.
4. Commit perubahan lalu buka URL GitHub Pages.

## API yang dibutuhkan
Frontend mengharapkan endpoint berikut:
- `GET /api/admin/licenses` → `{ "licenses": [{ "id": "...", "key_mask": "JEFF-****", "status": "UNBOUND", "note": "...", "expires_at": 0 }] }`
- `POST /api/admin/licenses` body `{ "count": 1, "duration_days": 30, "note": "..." }` → `{ "keys": ["JEFF-XXXX-XXXX-XXXX"] }`
- `POST /api/admin/revoke` body `{ "license_id": "..." }`
- `POST /api/admin/reset-device` body `{ "license_id": "..." }`

## Keamanan wajib sebelum dipakai
- Lindungi endpoint `/api/admin/*` dengan Cloudflare Access atau autentikasi admin server-side yang setara.
- Worker wajib memverifikasi identitas admin pada setiap request admin. Jangan hanya mengandalkan tombol tersembunyi atau CORS.
- Jangan pernah menaruh admin token, private signing key, database credential, atau rahasia lain di HTML/JavaScript GitHub Pages.
- Atur CORS Worker hanya untuk origin GitHub Pages yang benar dan tangani preflight `OPTIONS`.
- Simpan hash License Key di D1, bukan key mentah. Tampilkan key penuh hanya sekali ketika baru dibuat.
- Batasi request dan catat tindakan admin.

**Status integrasi:** UI sudah disiapkan, tetapi belum terhubung ke Worker API. Jangan gunakan untuk mengelola lisensi sungguhan sebelum endpoint dan perlindungan admin diimplementasikan serta diuji.
